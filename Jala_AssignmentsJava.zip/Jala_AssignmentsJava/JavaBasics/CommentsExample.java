package JavaBasics;

public class CommentsExample {
    public static void main(String[] args) {
        // This is a single-line comment.
        String name = "Ajay";

        /*
         * This is a multi-line comment.
         * The next line of code will print the name to the screen.
         */
        System.out.println("My name is " + name);
    }
}
