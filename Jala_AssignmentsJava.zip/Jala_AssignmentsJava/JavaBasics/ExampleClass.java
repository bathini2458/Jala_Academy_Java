package JavaBasics;

public class ExampleClass {

    public void exampleMethod() {
        System.out.println("This is method.");
    }

    public static void main(String[] args) {

        ExampleClass obj = new ExampleClass();

        obj.exampleMethod();
    }

}
