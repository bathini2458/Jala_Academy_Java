package JavaBasics;

public class Vaiables {
    // Global variable
    static int var = 100;

    public static void main(String[] args) {
        // Local variable
        int var = 200;

        System.out.println("Local variable: " + var);

        System.out.println("Global variable: " + Vaiables.var);
    }
}
