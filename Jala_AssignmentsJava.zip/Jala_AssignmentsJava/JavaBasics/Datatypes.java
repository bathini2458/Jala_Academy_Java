package JavaBasics;

public class Datatypes {
    public static void main(String[] args) {
        int intVar = 100;
        boolean boolVar = true;
        char charVar = 'A';
        float floatVar = 10.58f;
        double doubleVar = 20.56;

        System.out.println("Integer: " + intVar);
        System.out.println("Boolean: " + boolVar);
        System.out.println("Character: " + charVar);
        System.out.println("Float: " + floatVar);
        System.out.println("Double: " + doubleVar);
    }

}
