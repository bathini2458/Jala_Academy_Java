package JavaBasics;

public class PrintName {
    public static void main(String[] args) {
        String name = "Ajay";
        System.out.println("My name is " + name);
    }
}
