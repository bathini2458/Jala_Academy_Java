package JavaBasics;

public class PrintNameFunction {
    // Function to print
    public void printName() {
        System.out.println("My name is Ajay");
    }

    public static void main(String[] args) {

        PrintNameFunction obj = new PrintNameFunction();

        obj.printName();
    }

}
