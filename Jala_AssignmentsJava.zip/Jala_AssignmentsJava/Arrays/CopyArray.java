package Arrays;

import java.util.Arrays;

public class CopyArray {
    public static int[] copyArray(int[] arr) {
        int[] newArr = new int[arr.length];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        return newArr;
    }

    public static void main(String[] args) {
        int[] arr = { 1, 2, 3, 4, 5 };
        int[] copiedArray = copyArray(arr);
        System.out.println("Copied array: " + Arrays.toString(copiedArray));
    }
}
