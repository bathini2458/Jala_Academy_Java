package Arrays;

import java.util.HashSet;
import java.util.Set;

public class CommonValues {
    public static Set<Integer> findCommon(int[] arr1, int[] arr2) {
        Set<Integer> common = new HashSet<>();
        Set<Integer> set = new HashSet<>();
        for (int num : arr1) {
            set.add(num);
        }
        for (int num : arr2) {
            if (set.contains(num)) {
                common.add(num);
            }
        }
        return common;
    }

    public static void main(String[] args) {
        int[] arr1 = { 1, 2, 3, 4, 5 };
        int[] arr2 = { 3, 4, 5, 6, 7 };
        System.out.println("Common values: " + findCommon(arr1, arr2));
    }
}
