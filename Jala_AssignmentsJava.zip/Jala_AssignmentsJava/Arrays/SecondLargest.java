package Arrays;

public class SecondLargest {
    public static int findSecondLargest(int[] arr) {
        int largest = arr[0];
        int secondLargest = arr[1];
        for (int num : arr) {
            if (num > largest) {
                secondLargest = largest;
                largest = num;
            } else if (num > secondLargest && num != largest) {
                secondLargest = num;
            }
        }
        return secondLargest;
    }

    public static void main(String[] args) {
        int[] arr = { 4, 5 };
        System.out.println("Second largest number: " + findSecondLargest(arr));
    }

}
