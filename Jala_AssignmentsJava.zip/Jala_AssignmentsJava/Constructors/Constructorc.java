package Constructors;

class Calculator {
    int result;

    // Default constructor
    Calculator() {
        result = 0;
        System.out.println("Default Constructor: Result initialized to " + result);
    }

    // One-argument const
    Calculator(int num) {
        result = num;
        System.out.println("One Argument Constructor: Result set to " + result);
    }

    // Two-argument cons
    Calculator(int num1, int num2) {
        result = num1 + num2;
        System.out.println("Two Argument Constructor: Result of " + num1 + " + " + num2 + " is " + result);
    }

    int getResult() {
        return result;
    }
}

public class Constructorc {
    public static void main(String[] args) {
        Calculator calc1 = new Calculator();
        Calculator calc2 = new Calculator(10);
        Calculator calc3 = new Calculator(15, 25);

        System.out.println("Result from calc1: " + calc1.getResult());
        System.out.println("Result from calc2: " + calc2.getResult());
        System.out.println("Result from calc3: " + calc3.getResult());
    }
}
