package Collections;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListc {
    public static void main(String[] args) {
        ArrayList<String> stringList = new ArrayList<>();

        // Adding 10 string elements
        for (int i = 1; i <= 10; i++) {
            stringList.add("String " + i);
        }

        // Add an element to the ArrayList
        stringList.add("New String");

        // Iterator
        Iterator<String> iterator = stringList.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }

        // Add an element at a specific index
        stringList.add(2, "Inserted Stringnew ");

        // Remove an element from the ArrayList
        stringList.remove("String 5");
        stringList.remove(0);

        // Update the element at a specific index
        stringList.set(1, "Updated String100");

        // Check if an element is present at a particular index
        if (stringList.size() > 3) {
            System.out.println("Element at index 3: " + stringList.get(3));
        }

        // Get an element at a particular index
        System.out.println("Element at index 1: " + stringList.get(1));

        // Find out the size of the ArrayList
        System.out.println("Size of ArrayList: " + stringList.size());

        // Check if a given element is present in the ArrayList
        System.out.println("Contains 'String 3': " + stringList.contains("String 3"));

        // Remove all elements of the ArrayList
        stringList.clear();
        System.out.println("ArrayList cleared. Size: " + stringList.size());
    }
}
