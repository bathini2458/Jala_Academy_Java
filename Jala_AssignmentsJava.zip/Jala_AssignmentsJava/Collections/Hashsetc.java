package Collections;

import java.util.HashSet;

public class Hashsetc {
    public static void main(String[] args) {
        HashSet<String> stringSet = new HashSet<>();

        // Adding elements
        for (int i = 1; i <= 10; i++) {
            stringSet.add("Ele " + i);
        }

        // Add a duplicate element
        stringSet.add("Ele 1"); // This won't be added again

        // Print all elements
        System.out.println("HashSet elements: " + stringSet);

        // Check if a specific element is present
        System.out.println("Contains 'Element 5': " + stringSet.contains("Ele 5"));

        // Remove an element
        stringSet.remove("Element 3");
        System.out.println("After removing 'Element 3': " + stringSet);

        // Get the size of the HashSet
        System.out.println("Size of HashSet: " + stringSet.size());

        // Clear all elements
        stringSet.clear();
        System.out.println("HashSet cleared. Size: " + stringSet.size());
    }
}
