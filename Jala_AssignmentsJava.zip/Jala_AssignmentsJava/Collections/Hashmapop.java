package Collections;

import java.util.HashMap;

public class Hashmapop {
    public static void main(String[] args) {
        HashMap<Integer, String> studentMap = new HashMap<>();

        // Inserting 10 key-value pairs
        for (int i = 1; i <= 10; i++) {
            studentMap.put(i, "Student " + i);
        }

        // Insert a key-value mapping
        studentMap.put(11, "New Student");

        // Fetch the value of a key ... display
        System.out.println("Value for key 5: " + studentMap.get(5));

        // Create a copy of HashMap
        HashMap<Integer, String> clonedMap = (HashMap<Integer, String>) studentMap.clone();

        // Check if a given key is in the map
        System.out.println("Contains key 3: " + studentMap.containsKey(3));

        // Check if a value is in the map
        System.out.println("Contains value 'Student 1': " + studentMap.containsValue("Student 1"));

        // Check if the map is empty
        System.out.println("Is map empty? " + studentMap.isEmpty());

        // Print the size of the map
        System.out.println("Size of HashMap: " + studentMap.size());

        // Print all the keys of the map
        System.out.println("Keys: " + studentMap.keySet());

        // Print all the values of the map
        System.out.println("Values: " + studentMap.values());

        // Remove a specific key-value pair
        studentMap.remove(2);
        System.out.println("After removing key 2: " + studentMap);

        // Copy all elements of the map to another map
        HashMap<Integer, String> anotherMap = new HashMap<>(studentMap);
        System.out.println("Copied Map: " + anotherMap);
    }
}
