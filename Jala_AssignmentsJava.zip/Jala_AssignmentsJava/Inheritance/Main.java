package Inheritance;

class A {
    String name = "Class A";

    void method1() {
        System.out.println("Method 1 from Class A");
    }

    void method2() {
        System.out.println("Method 2 from Class A");
    }

    void overriddenMethod() {
        System.out.println("Overridden Method from Class A");
    }
}

class B extends A {
    String name = "Class B";

    void method1() {
        System.out.println("Method 1 from Class B");
    }

    void method2() {
        System.out.println("Method 2 from Class B");
    }

    void overriddenMethod() {
        System.out.println("Overridden Method from Class B");
    }
}

class C extends B {
    String name = "Class C";

    void method1() {
        System.out.println("Method 1 from Class C");
    }

    void method2() {
        System.out.println("Method 2 from Class C");
    }

    void overriddenMethod() {
        System.out.println("Overridden Method from Class C");
    }
}

public class Main {
    public static void main(String[] args) {
        A objA = new A();
        B objB = new B();
        C objC = new C();

        objA.method1();
        objA.method2();
        objA.overriddenMethod();
        System.out.println(objA.name);

        objB.method1();
        objB.method2();
        objB.overriddenMethod();
        System.out.println(objB.name);

        objC.method1();
        objC.method2();
        objC.overriddenMethod();
        System.out.println(objC.name);

        A refB = objB;
        A refC = objC;
        refB.overriddenMethod();
        refC.overriddenMethod();

        System.out.println("Accessing instance variables:");
        System.out.println("From A: " + objA.name);
        System.out.println("From B: " + refB.name);
        System.out.println("From C: " + refC.name);
    }
}
