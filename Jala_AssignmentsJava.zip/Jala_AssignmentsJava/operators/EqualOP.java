package operators;

public class EqualOP {

    public static void main(String[] args) {
        int a = 10;
        int b = 20;

        System.out.println("Equal: " + (a == b));
        System.out.println("Not Equal: " + (a != b));
    }
}
