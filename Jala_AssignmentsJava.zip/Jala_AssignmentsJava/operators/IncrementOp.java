package operators;

public class IncrementOp {

    public static void main(String[] args) {
        int a = 10;

        System.out.println("Increment: " + (++a));
        System.out.println("Decrement: " + (--a));
    }
}
