package operators;

public class LogicalOP {
    public static void main(String[] args) {
        boolean a = true;
        boolean b = false;

        System.out.println("Logical AND: " + (a && b));
        System.out.println("Logical OR: " + (a || b));
        System.out.println("Logical NOT a: " + (!a));
        System.out.println("Logical NOT b: " + (!b));
    }

}
