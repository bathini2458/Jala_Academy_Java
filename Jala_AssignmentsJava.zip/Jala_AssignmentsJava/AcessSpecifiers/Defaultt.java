package AcessSpecifiers;

class DefaultClass {
    int defaultField = 20;

    void defaultMethod() {
        System.out.println("Default Method called");
    }
}

public class Defaultt {
    public static void main(String[] args) {
        DefaultClass defaultObj = new DefaultClass();
        System.out.println("Default Field: " + defaultObj.defaultField);
        defaultObj.defaultMethod();
    }
}
