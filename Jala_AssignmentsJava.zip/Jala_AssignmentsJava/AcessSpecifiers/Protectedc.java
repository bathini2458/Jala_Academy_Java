package AcessSpecifiers;

class ProtectedClass {
    protected int protectedField = 10;

    protected void protectedMethod() {
        System.out.println("Protected Method called");
    }
}

public class Protectedc {
    public static void main(String[] args) {
        ProtectedClass obj = new ProtectedClass();
        System.out.println("Protected Field: " + obj.protectedField);
        obj.protectedMethod();
    }
}
