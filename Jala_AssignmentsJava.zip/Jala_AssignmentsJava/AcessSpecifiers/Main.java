package AcessSpecifiers;

class PrivateClass {
    private int privateField = 10;

    private void privateMethod() {
        System.out.println("Private Method called");
    }

    public void display() {
        System.out.println("Private Field: " + privateField);
        privateMethod();
    }
}

class SubClass extends PrivateClass {
    void tryAccess() {
        // Cannot access privateField or privateMethod from PrivateClass
    }
}

public class Main {
    public static void main(String[] args) {
        PrivateClass privateObj = new PrivateClass();
        privateObj.display();

        SubClass subObj = new SubClass();
        subObj.tryAccess();
    }
}
