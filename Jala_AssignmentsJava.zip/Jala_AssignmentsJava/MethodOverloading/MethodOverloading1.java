package MethodOverloading;

class MethodOverloading {

    // 1. Same name, different para same data type
    void display(int num) {
        System.out.println("Display with one integer: " + num);
    }

    void display(int num1, int num2) {
        System.out.println("Display with two integers: " + num1 + ", " + num2);
    }

    // 2. Same name, different number of parameters (different types)
    void show(double num) {
        System.out.println("Show with one double: " + num);
    }

    void show(String str) {
        System.out.println("Show with one string: " + str);
    }

    // 3. Same name, same number of parameters (different types)
    void calculate(int num1, double num2) {
        System.out.println("Calculate with int and double: " + (num1 + num2));
    }

    void calculate(double num1, int num2) {
        System.out.println("Calculate with double and int: " + (num1 + num2));
    }

    // 5. Same name, same parameters but different return types (not possible in
    // Java)

    int add(int a, int b) {
        return a + b;
    }

    String add(String a, String b) {
        return a + b;
    }
}

public class MethodOverloading1 {
    public static void main(String[] args) {
        MethodOverloading obj = new MethodOverloading();

        // Calling methods with the same name but different parameters
        obj.display(10);
        obj.display(10, 20);

        obj.show(5.5);
        obj.show("ajay");

        // Calling methods with the same name and same number of parameters of different
        // types
        obj.calculate(10, 20.5);
        obj.calculate(15.5, 10);

        // Calling methods with the same name but different return types
        int sumInt = obj.add(5, 10);
        String sumString = obj.add("bathini ", "Ajay");
        System.out.println("Integer add res: " + sumInt);
        System.out.println("String conc res: " + sumString);
    }
}
