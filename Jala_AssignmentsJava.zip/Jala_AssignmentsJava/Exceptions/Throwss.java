package Exceptions;

public class Throwss {
    static void throwException() throws Exception {
        throw new Exception("Exception thrown");
    }

    public static void main(String[] args) throws Exception {
        throwException();
    }
}
