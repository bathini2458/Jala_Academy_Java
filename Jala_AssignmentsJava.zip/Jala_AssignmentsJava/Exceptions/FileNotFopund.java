package Exceptions;

import java.io.FileNotFoundException;

public class FileNotFopund {
    public static void main(String[] args) {
        try {
            throw new FileNotFoundException("File not found exception triggered");
        } catch (FileNotFoundException e) {
            System.out.println("Caught FileNotFoundException: " + e.getMessage());
        }
    }
}
