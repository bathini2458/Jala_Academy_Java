package Exceptions;

public class Arithmeticexp {
    public static void main(String[] args) {
        try {
            int result = 10 / 0;
        } catch (ArithmeticException e) {
            System.out.println("Handled Arithmetic Exception:  error it is");
        }
    }
}
