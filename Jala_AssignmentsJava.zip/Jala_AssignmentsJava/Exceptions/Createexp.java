package Exceptions;

class MyCustomException extends Exception {
    public MyCustomException(String message) {
        super(message);
    }
}

public class Createexp {
    public static void main(String[] args) {
        try {
            throw new MyCustomException("This is a my own exception");
        } catch (MyCustomException e) {
            System.out.println("Caught Custom Exception: " + e.getMessage());
        }
    }
}
