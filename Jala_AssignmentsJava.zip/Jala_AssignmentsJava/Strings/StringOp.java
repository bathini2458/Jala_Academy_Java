package Strings;

public class StringOp {
    public class StringOperations {
        public static void main(String[] args) {
            // Different ways creating a string
            String str1 = "Bathini";
            String str2 = new String("Ajay");
            char[] charArray = { 'H', 'e', 'l', 'l', 'o' };
            String str3 = new String(charArray);

            // Concatenating two strings using + operator
            String concatenatedString = str1 + " " + str2;
            System.out.println("Concatenated String: " + concatenatedString);

            // Finding the length of the string
            int length = str1.length();
            System.out.println("Length of str1: " + length);

            // Extract a string using Substring
            String substring = str1.substring(1, 4);
            System.out.println("Substring of str1: " + substring);

            // Searching in strings using indexOf()
            int index = str1.indexOf('e');
            System.out.println("Index of 'e' in str1: " + index);

            // Matching a String Against a Regular Expression With matches()
            boolean matches = str1.matches("Hello");
            System.out.println("Does str1 match 'Hello'? " + matches);

            // Comparing strings using the methods equals()
            boolean equals = str1.equals(str3);
            System.out.println("Does str1 equal str3? " + equals);

            // equalsIgnoreCase()
            boolean equalsIgnoreCase = str1.equalsIgnoreCase("hello");
            System.out.println("Does str1 equal 'hello' (ignore case)? " + equalsIgnoreCase);

            // startsWith()
            boolean startsWith = str1.startsWith("He");
            System.out.println("Does str1 start with 'He'? " + startsWith);

            // endsWith()
            boolean endsWith = str1.endsWith("lo");
            System.out.println("Does str1 end with 'lo'? " + endsWith);

            // compareTo()
            int compareTo = str1.compareTo(str2);
            System.out.println("Comparing str1 and str2: " + compareTo);

            // Trimming strings with trim()
            String str4 = "   Hello World   ";
            String trimmedString = str4.trim();
            System.out.println("Trimmed string: '" + trimmedString + "'");

            // Replacing characters in strings with replace()
            String replacedString = str1.replace('l', 'p');
            System.out.println("Replaced string: " + replacedString);

            // Splitting strings with split()
            String[] splitString = str2.split("o");
            System.out.println("Split str2 by 'o':");
            for (String s : splitString) {
                System.out.println(s);
            }

            // Converting Numbers to Strings with valueOf()
            int number = 123;
            String numberString = String.valueOf(number);
            System.out.println("Number to string: " + numberString);

            // Converting integer objects to Strings
            Integer integerObject = 456;
            String integerString = integerObject.toString();
            System.out.println("Integer object to string: " + integerString);

            // Converting to uppercase and lowercase
            String upperCaseString = str1.toUpperCase();
            String lowerCaseString = str2.toLowerCase();
            System.out.println("Uppercase str1: " + upperCaseString);
            System.out.println("Lowercase str2: " + lowerCaseString);
        }
    }

}
