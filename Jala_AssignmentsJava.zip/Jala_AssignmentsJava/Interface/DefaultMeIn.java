package Interface;

interface DefaultMethodInterface {
    default void defaultMethod() {
        System.out.println("Default method called.");
    }
}

class DefaultMethodClass implements DefaultMethodInterface {
    // No implementation for defaultMethod
}

public class DefaultMeIn {
    public static void main(String[] args) {
        DefaultMethodClass obj = new DefaultMethodClass();
        obj.defaultMethod();
    }
}
