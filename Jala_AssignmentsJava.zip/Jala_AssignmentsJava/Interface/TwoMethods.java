package Interface;

interface FirstInterface {
    void firstMethod();
}

interface SecondInterface {
    void secondMethod();
}

class CombinedClass implements FirstInterface, SecondInterface {
    public void firstMethod() {
        System.out.println("First method implemented.");
    }

    public void secondMethod() {
        System.out.println("Second method implemented.");
    }
}

public class TwoMethods {
    public static void main(String[] args) {
        CombinedClass obj = new CombinedClass();
        obj.firstMethod();
        obj.secondMethod();
    }
}
