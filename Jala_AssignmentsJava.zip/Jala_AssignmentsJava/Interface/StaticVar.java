package Interface;

interface StaticFinalInterface {
    static final int CONSTANT = 100;

    void printConstant();
}

class StaticFinalClass implements StaticFinalInterface {
    public void printConstant() {
        System.out.println("Constant value: " + CONSTANT);
    }
}

public class StaticVar {
    public static void main(String[] args) {
        StaticFinalClass obj = new StaticFinalClass();
        obj.printConstant();
    }
}
