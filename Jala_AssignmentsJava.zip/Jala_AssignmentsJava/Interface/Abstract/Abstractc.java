package Abstract;

abstract class NumberProcessor {
    abstract void processNumber(int num);

    void displayMessage() {
        System.out.println("Processing numbers.");
    }
}

class SquareProcessor extends NumberProcessor {
    void processNumber(int num) {
        int square = num * num;
        System.out.println("Square of " + num + " is " + square);
    }

    void displaySquare(int num) {
        int square = num * num;
        System.out.println("Displaying square: " + square);
    }
}

public class Abstractc {
    public static void main(String[] args) {
        SquareProcessor squareProcessor = new SquareProcessor();

        squareProcessor.displayMessage();

        squareProcessor.processNumber(5);

        squareProcessor.displaySquare(3);
    }
}
