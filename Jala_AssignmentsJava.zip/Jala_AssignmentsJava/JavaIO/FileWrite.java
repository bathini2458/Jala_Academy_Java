package JavaIO;

import java.io.FileWriter;
import java.io.IOException;

public class FileWrite {
    public static void main(String[] args) {
        String text = "Hello, FileWriter!";
        try (FileWriter fw = new FileWriter("output.txt")) {
            fw.write(text);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
