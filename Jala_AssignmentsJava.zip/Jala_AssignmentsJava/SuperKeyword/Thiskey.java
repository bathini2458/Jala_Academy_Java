package SuperKeyword;

class Parent {
    int parentField = 10;

    Parent() {
        System.out.println("Parent Constructor ");
    }

    void displayParentField() {
        System.out.println("Parent Field: " + parentField);
    }
}

class Child extends Parent {
    int childField = 20;

    Child() {
        this(30); // Calls the parameterized constructor of Child
        System.out.println("Child Constructor");
    }

    Child(int value) {
        childField = value;
    }

    void displayFields() {
        System.out.println("Child Field: " + this.childField);
        super.displayParentField();
    }

    void display() {
        System.out.println("Calling from Child class:");
        displayFields();
    }
}

public class Thiskey {
    public static void main(String[] args) {
        Child childObj = new Child();
        childObj.display();
    }
}
